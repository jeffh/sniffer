__all__ = [
    '__author__', '__author_email__', '__copyright__', '__credits__',
    '__license__', '__version__'
]


__author__ = "Jeff Hui"
__author_email__ = 'contrib@jeffhui.net'
__copyright__ = "Copyright 2010, Jeff Hui"
__credits__ = ["Jeff Hui"]

__license__ = "MIT"
__version__ = "0.1.1"
